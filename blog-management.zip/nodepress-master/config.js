module.exports = {
	'WEBAPP_PORT' : 8080,
	'MONGO_HOST' : 'localhost',
	'MONGO_SCHEMA' : 'nodepress',
	'BLOG_NAME' : 'Nodepress Weblog',
	'BLOG_DESCRIPTION' : 'Just another nodepress weblog.',
	'POSTS_PER_PAGE' : 5
};