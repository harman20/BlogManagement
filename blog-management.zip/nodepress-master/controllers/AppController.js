
module.exports = function() {
    this.defaultMethod = function() {
        return 'default method';
    };
};
